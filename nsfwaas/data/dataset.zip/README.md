# Disclaimer
This folder contains images that can hurt your sensibility and are used for research and testing purposes only of the Yahoo! NSFW (Not Suitable For Work) Neural Network available [here](https://github.com/yahoo/open_nsfw). There are three images, one is a person that is partially undressed, one is half of the body naked, the last is dressed with swimsuit. For each of image in this folder, you can test the accuracy of the model running

```bash
./test.sh
```

You can even specify a different folder with `test.sh [PORT] [FOLDER]`.
